from flask import Flask, render_template, request, redirect
import os, json
import boto3
from botocore.exceptions import NoCredentialsError
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'  # still needed for os.makedirs
DATA_FILE = 'pets.json'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# AWS S3 Configuration 
S3_BUCKET = os.getenv('S3_BUCKET')
AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
AWS_REGION = os.getenv('AWS_REGION')

# Initialize S3 
s3 = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

# Ensure folders and data file exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w') as f:
        json.dump([], f)

@app.route('/')
def index():
    with open(DATA_FILE) as f:
        pets = json.load(f)
    return render_template('index.html', pets=pets)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        name = request.form['name']
        breed = request.form['breed']
        age = request.form['age']
        photo = request.files['photo']
        filename = secure_filename(photo.filename)

        try:
            # Upload to S3
            s3.upload_fileobj(
                photo,
                S3_BUCKET,
                filename,
                ExtraArgs={'ACL': 'public-read'}
            )
            image_url = f"https://{S3_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{filename}"
        except NoCredentialsError:
            return "AWS credentials not available", 403

        new_pet = {"name": name, "breed": breed, "age": age, "image": image_url}

        with open(DATA_FILE) as f:
            pets = json.load(f)
        pets.append(new_pet)
        with open(DATA_FILE, 'w') as f:
            json.dump(pets, f)

        return redirect('/')
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

